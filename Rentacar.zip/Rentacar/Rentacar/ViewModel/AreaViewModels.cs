﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Rentacar.Models;

namespace Rentacar.ViewModel
{
    public class AreaViewModels
    {
        //public string RegionName { get; set; }
        public string CodeName { get; set; }
        public string Code { get; set; }
        public Guid AreaCodeId { get; set; }

        public AreaViewModels()
        {
            string RegionNameList = new SelectList(new List<RegionName>() { new RegionName() { AreaCodeId }, new RegionName() { AreaCodeId } });
        }
       
    }

}