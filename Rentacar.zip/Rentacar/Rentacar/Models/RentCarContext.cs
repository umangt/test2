﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Rentacar.Models
{
    public class RentCarContext : DbContext
    {
        public DbSet<Area> Areas { get; set; }
        public DbSet<Region> Regions { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Area>().ToTable("Area");
            modelBuilder.Entity<Region>().ToTable("Region");

            modelBuilder.Entity<Area>().HasRequired(x => x.Region).WithMany(x => x.Areas).HasForeignKey(x => x.RegionId);

            base.OnModelCreating(modelBuilder);
        }

    }


}