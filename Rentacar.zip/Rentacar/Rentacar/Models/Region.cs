﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Rentacar.Models
{
   
    public class Region
    {
        [Key]
        public Guid RegionId { get; set; }
        public string RegionName { get; set; }

        public IList<Area> Areas { get; set; }
    }
}