﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Rentacar.Models
{
   
    public class Area
    {
        [Key]
        public Guid AreaCodeId { get; set; }
        public string AreaCode { get; set; }
        public string AreaCodeName { get; set; }
        public Guid RegionId { get; set; }

        public Region Region { get; set; }
    }
}