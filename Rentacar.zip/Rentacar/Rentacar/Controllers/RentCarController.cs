﻿using Rentacar.Models;
using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Collections.Generic;
using Rentacar.ViewModel;
using System.Net;

namespace Rentacar.Controllers
{
    public class RentCarController : Controller
    {
        
        // GET: /RentCar/
        public ActionResult Index()
        {
            RentCarContext car = new RentCarContext();
            List<Area> areas = car.Areas.Include("Region").ToList();
            List<AreaViewModels> areasViewModel = new List<AreaViewModels>();
           
            foreach (Area area in areas)
            {
               AreaViewModels areaViewModel = new AreaViewModels();

                areaViewModel.CodeName = area.AreaCodeName;           
                areaViewModel.RegionName = area.Region.RegionName; 
                areaViewModel.Code = area.AreaCode;
                areaViewModel.AreaCodeId = area.AreaCodeId;
                areasViewModel.Add(areaViewModel);
            }

            return View(areasViewModel);
        }


        //GET: /RentCar/Create

        [HttpGet]
        public ActionResult CreateGet()
        {

            return PartialView();
        }

        //POST : /RentCar/Create

        [HttpPost]
        //public ActionResult CreatePost(string areaCode, string areaCodeName, string regionName)
        public ActionResult CreatePost(Area area)
        {
            RentCarContext car = new RentCarContext();
            //List<Area> areas = car.Areas.Include("Region").ToList();

            //AreaViewModels areaViewModelAdd = new AreaViewModels();

            //areaViewModelAdd.AreaCodeId = new Guid();
            //areaViewModelAdd.Code = areaCode;
            //areaViewModelAdd.CodeName = areaCodeName;
            //areaViewModelAdd.RegionName = regionName;
            //car.SaveChanges();
            if(ModelState.IsValid)
            {
                car.Areas.Add(area);
                
                car.SaveChanges();
                return RedirectToAction("Index");
            }

            return View("Index");

        }



        //GET : /Rentcar/Edit
        [HttpGet]
        public ActionResult EditGet(Guid? Id)
        {
            RentCarContext car = new RentCarContext();
            List<Area> areas = car.Areas.Include("Region").ToList();
            List<AreaViewModels> areaViewModel = new List<AreaViewModels>();
            
          var toUpdate = areas.Find(x => x.AreaCodeId.Equals(Id));
            //var toUpdate = areaViewModel.Find(x => x.AreaCodeId.Equals(Id));

           //var area = new Area { 
            //AreaCode = toUpdate.AreaCode,
            //AreaCodeId = toUpdate.AreaCodeId,
            //AreaCodeName = toUpdate.AreaCodeName,
            //Region = toUpdate.Region
            //};

          AreaViewModels areaViewModelEdit = new AreaViewModels();
          areaViewModelEdit.AreaCodeId = toUpdate.AreaCodeId;
          areaViewModelEdit.Code = toUpdate.AreaCode;
          areaViewModelEdit.CodeName = toUpdate.AreaCodeName;
          areaViewModelEdit.RegionName = toUpdate.Region.RegionName;



          return View(areaViewModelEdit);
           
        }



        //POST : /Rentcar/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public ActionResult Edit(string areaCode, string areaCodeName, string regionName)        
        public ActionResult Edit(AreaViewModels areaViewModel)
        {
            RentCarContext car = new RentCarContext();
            List<Area> areas = car.Areas.Include("Region").ToList();


            AreaViewModels areaViewModelEdit = new AreaViewModels();
            
            
            if(TryUpdateModel (areaViewModel))
            {
                areaViewModelEdit.Code = areaViewModel.Code;
                areaViewModelEdit.CodeName = areaViewModel.CodeName;
                areaViewModelEdit.RegionName = areaViewModel.RegionName;
                car.Entry(areaViewModel).State = System.Data.Entity.EntityState.Modified;

            car.SaveChanges();

            return RedirectToAction("Index");
            }
            return View("Index");
        }
            


        // : /RentCar/Delete
        [HttpDelete]
        public ActionResult Delete(Guid? Id)
        {
            RentCarContext car = new RentCarContext();
            List<Area> areas = car.Areas.Include("Region").ToList();
          

            //var toDelete = areas.Find(x => x.AreaCodeId.Equals(Id));
            //AreaViewModels areaViewModelDelete = new AreaViewModels();
            //areaViewModelDelete.AreaCodeId = toDelete.AreaCodeId;
            //areaViewModelDelete.Code = toDelete.AreaCode;
            //areaViewModelDelete.CodeName = toDelete.AreaCodeName;
            //areaViewModelDelete.RegionName = toDelete.Region.RegionName;

            return RedirectToAction("Index");
           
        }

        //[HttpPost]
        //public ActionResult ConfirmDelete()
        //{

        //    return RedirectToAction ("Index");
        //}
	}
}